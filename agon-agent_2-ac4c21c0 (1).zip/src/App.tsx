import { BrowserRouter } from 'react-router-dom';
import Background from './components/Background';
import ToastHost from './components/ToastHost';
import AppRoutes from './AppRoutes';
import './lib/apiExtensions';

export default function App() {
  return (
    <BrowserRouter>
      <ToastHost>
        <Background />
        <AppRoutes />
      </ToastHost>
    </BrowserRouter>
  );
}
