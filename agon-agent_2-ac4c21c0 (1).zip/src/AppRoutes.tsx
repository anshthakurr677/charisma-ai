import { Navigate, Route, Routes } from 'react-router-dom';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import AppShell from './pages/AppShell';
import Dashboard from './pages/Dashboard';
import Missions from './pages/Missions';
import Challenges from './pages/Challenges';
import Mentor from './pages/Mentor';
import Progress from './pages/Progress';
import Profile from './pages/Profile';
import Premium from './pages/Premium';

import AdminShell from './pages/admin/AdminShell';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminUsers from './pages/admin/AdminUsers';
import AdminMissions from './pages/admin/AdminMissions';
import AdminChallenges from './pages/admin/AdminChallenges';
import AdminAnalytics from './pages/admin/AdminAnalytics';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/premium" element={<Premium />} />

      <Route path="/app" element={<AppShell />}>
        <Route index element={<Dashboard />} />
        <Route path="missions" element={<Missions />} />
        <Route path="challenges" element={<Challenges />} />
        <Route path="mentor" element={<Mentor />} />
        <Route path="progress" element={<Progress />} />
        <Route path="profile" element={<Profile />} />
      </Route>

      <Route path="/admin" element={<AdminShell />}>
        <Route index element={<AdminDashboard />} />
        <Route path="users" element={<AdminUsers />} />
        <Route path="missions" element={<AdminMissions />} />
        <Route path="challenges" element={<AdminChallenges />} />
        <Route path="analytics" element={<AdminAnalytics />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
