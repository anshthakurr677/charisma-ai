// Optional helper extensions for future evolution.
// Kept separate to avoid cluttering the core api client.

import { api } from './api';

export const apiExtensions = {
  progressAwardBonus: async (user_id: string, xp_delta: number) => {
    return fetch('/api/progress', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id, source: 'daily_login', xp_delta, meta: { reason: 'daily_login_bonus' } }),
    }).then((r) => r.json());
  },
};

// Keep tree-shaking happy; allows importing via api.progressAwardBonus after composition.
(Object.assign(api as any, { progressAwardBonus: apiExtensions.progressAwardBonus }));
