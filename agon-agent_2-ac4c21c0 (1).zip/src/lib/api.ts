export type ApiError = { error: string };

async function json<T>(res: Response): Promise<T> {
  const data = await res.json();
  if (!res.ok) throw new Error((data as any)?.error || `HTTP ${res.status}`);
  return data;
}

export const api = {
  users: {
    list: () => fetch('/api/users').then((r) => json<any[]>(r)),
    create: (payload: { username: string; email: string }) =>
      fetch('/api/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }).then((r) => json<any>(r)),
    update: (payload: { id: string; username?: string; premium_status?: boolean }) =>
      fetch('/api/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }).then((r) => json<any>(r)),
  },
  missions: {
    list: (params?: { difficulty?: string; active?: boolean }) => {
      const qs = new URLSearchParams();
      if (params?.difficulty) qs.set('difficulty', params.difficulty);
      if (typeof params?.active === 'boolean') qs.set('active', String(params.active));
      const url = `/api/missions${qs.toString() ? `?${qs.toString()}` : ''}`;
      return fetch(url).then((r) => json<any[]>(r));
    },
  },
  challenges: {
    list: (params?: { tier?: string; active?: boolean }) => {
      const qs = new URLSearchParams();
      if (params?.tier) qs.set('tier', params.tier);
      if (typeof params?.active === 'boolean') qs.set('active', String(params.active));
      const url = `/api/challenges${qs.toString() ? `?${qs.toString()}` : ''}`;
      return fetch(url).then((r) => json<any[]>(r));
    },
  },
  achievements: {
    list: () => fetch('/api/achievements').then((r) => json<any[]>(r)),
  },
  daily: {
    list: (user_id: string) => fetch(`/api/daily?user_id=${encodeURIComponent(user_id)}`).then((r) => json<any[]>(r)),
  },
  completeMission: (payload: { user_id: string; mission_id: number }) =>
    fetch('/api/complete-mission', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }).then((r) => json<any>(r)),
  progress: {
    get: (user_id: string) => fetch(`/api/progress?user_id=${encodeURIComponent(user_id)}`).then((r) => json<any>(r)),
  },
  admin: {
    metrics: () => fetch('/api/admin-metrics').then((r) => json<any>(r)),
  },
};
