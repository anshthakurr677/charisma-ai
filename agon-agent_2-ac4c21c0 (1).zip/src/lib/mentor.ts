export type ChatMessage = { id: string; role: 'user' | 'mentor'; text: string; ts: number };

export function renderChatMessage(msg: ChatMessage) {
  return msg;
}

const sample = [
  'Love the energy. Here\'s the move: pick one micro-action you can do in <60 seconds and do it now.',
  'Confidence isn\'t a mood — it\'s a pattern. Stack one win today: ask one question, hold eye contact, smile, and pause before speaking.',
  'Try this: slow your speech by 10% and end sentences with a downward tone. Instant presence upgrade.',
  'Social skill hack: be the person who *names the moment*. “That was actually fun.” People follow your frame.',
  'Discipline is identity. Say: “I\'m the kind of person who shows up.” Then prove it with 5 minutes.',
];

export async function sendMessage(text: string): Promise<ChatMessage> {
  return { id: crypto.randomUUID(), role: 'user', text, ts: Date.now() };
}

export async function receiveResponse(userText: string): Promise<ChatMessage> {
  await new Promise((r) => setTimeout(r, 650));
  const idx = Math.abs(hash(userText)) % sample.length;
  return { id: crypto.randomUUID(), role: 'mentor', text: sample[idx], ts: Date.now() };
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}
