export const LEVELS = [
  { level: 1, name: 'Beginner', floorXp: 0 },
  { level: 2, name: 'Improving', floorXp: 100 },
  { level: 3, name: 'Confident', floorXp: 250 },
  { level: 4, name: 'Social Pro', floorXp: 450 },
  { level: 5, name: 'Charismatic', floorXp: 700 },
  { level: 6, name: 'Leader', floorXp: 1000 },
  { level: 7, name: 'Influencer', floorXp: 1350 },
  { level: 8, name: 'Elite Communicator', floorXp: 1750 },
  { level: 9, name: 'Mastermind', floorXp: 2200 },
  { level: 10, name: 'Legendary', floorXp: 2700 },
] as const;

export function levelMeta(level: number) {
  const idx = Math.max(0, Math.min(LEVELS.length - 1, level - 1));
  const current = LEVELS[idx];
  const next = LEVELS[idx + 1] ?? { level: level + 1, name: 'Beyond', floorXp: current.floorXp + 600 };
  return { current, next };
}
