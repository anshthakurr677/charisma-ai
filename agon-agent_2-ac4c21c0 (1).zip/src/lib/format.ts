export const clamp = (n: number, a: number, b: number) => Math.min(b, Math.max(a, n));

export function formatINR(amount: number) {
  try {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
  } catch {
    return `₹${Math.round(amount)}`;
  }
}
