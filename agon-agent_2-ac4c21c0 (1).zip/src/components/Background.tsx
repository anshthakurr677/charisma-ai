import { motion } from 'framer-motion';

export default function Background() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(1200px_700px_at_20%_10%,rgba(151,106,157,0.18),transparent_60%),radial-gradient(900px_600px_at_75%_15%,rgba(80,53,153,0.22),transparent_55%),radial-gradient(1000px_700px_at_60%_85%,rgba(200,168,188,0.18),transparent_55%),linear-gradient(180deg,#050513_0%,#241564_100%)]" />

      <motion.div
        className="absolute -top-40 -left-40 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle_at_30%_30%,rgba(255,216,107,0.18),transparent_60%)] blur-2xl"
        animate={{ x: [0, 28, 0], y: [0, 18, 0], scale: [1, 1.03, 1] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute -bottom-48 -right-48 h-[640px] w-[640px] rounded-full bg-[radial-gradient(circle_at_35%_35%,rgba(151,106,157,0.20),transparent_60%)] blur-2xl"
        animate={{ x: [0, -28, 0], y: [0, -22, 0], scale: [1, 1.05, 1] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="absolute inset-0 opacity-[0.55]" style={{ backgroundImage: 'radial-gradient(rgba(200,168,188,0.18) 1px, transparent 1px)', backgroundSize: '34px 34px' }} />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.03)_50%,transparent_100%)] animate-[shimmer_10s_linear_infinite]" />
    </div>
  );
}
