import { NavLink } from 'react-router-dom';
import { Brain, Flame, Home, Swords, Target, User } from 'lucide-react';

const tabs = [
  { to: '/app', label: 'Home', icon: Home },
  { to: '/app/missions', label: 'Missions', icon: Target },
  { to: '/app/challenges', label: 'Challenges', icon: Swords },
  { to: '/app/mentor', label: 'AI Mentor', icon: Brain },
  { to: '/app/progress', label: 'Progress', icon: Flame },
  { to: '/app/profile', label: 'Profile', icon: User },
];

export default function BottomNav() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-[560px] px-4 pb-4">
      <div className="rounded-2xl border border-white/10 bg-[#16182D]/80 backdrop-blur-xl shadow-[0_0_0_1px_rgba(151,106,157,0.18),0_14px_40px_rgba(0,0,0,0.45)]">
        <div className="grid grid-cols-6">
          {tabs.map((t) => (
            <NavLink
              key={t.to}
              to={t.to}
              className={({ isActive }) =>
                `group flex flex-col items-center gap-1 px-1 py-3 text-[11px] transition ${
                  isActive ? 'text-white' : 'text-[#B8B8D0] hover:text-white'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div
                    className={`grid h-9 w-9 place-items-center rounded-xl transition ${
                      isActive
                        ? 'bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] shadow-[0_0_24px_rgba(151,106,157,0.35)]'
                        : 'bg-white/5 group-hover:bg-white/10'
                    }`}
                  >
                    <t.icon className="h-4.5 w-4.5" />
                  </div>
                  <div className={`leading-none ${isActive ? 'text-white' : 'text-[#B8B8D0]'}`}>{t.label}</div>
                </>
              )}
            </NavLink>
          ))}
        </div>
      </div>
    </div>
  );
}
