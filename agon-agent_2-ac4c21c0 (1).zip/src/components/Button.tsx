import { type ButtonHTMLAttributes } from 'react';

export default function Button({ className = '', ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={
        `rounded-2xl px-4 py-2.5 text-sm font-semibold text-white transition ` +
        `bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] ` +
        `shadow-[0_0_0_1px_rgba(151,106,157,0.25),0_12px_30px_rgba(0,0,0,0.35)] ` +
        `hover:brightness-110 active:translate-y-[1px] disabled:opacity-50 disabled:cursor-not-allowed ` +
        className
      }
    />
  );
}
