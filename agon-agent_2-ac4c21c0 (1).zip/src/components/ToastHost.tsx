import { createContext, useContext, useMemo, useState } from 'react';

type Toast = { id: string; title: string; detail?: string; tone?: 'good' | 'warn' | 'neutral' };

const ToastCtx = createContext<{
  push: (t: Omit<Toast, 'id'>) => void;
} | null>(null);

export function useToasts() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error('ToastHost missing');
  return ctx;
}

export default function ToastHost({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const api = useMemo(
    () => ({
      push: (t: Omit<Toast, 'id'>) => {
        const id = crypto.randomUUID();
        const toast: Toast = { id, ...t };
        setToasts((p) => [toast, ...p].slice(0, 3));
        window.setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 2600);
      },
    }),
    []
  );

  return (
    <ToastCtx.Provider value={api}>
      {children}
      <div className="fixed right-4 top-4 z-50 flex w-[min(380px,calc(100vw-2rem))] flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={
              'rounded-2xl border bg-[#16182D]/85 px-4 py-3 text-sm shadow-[0_20px_60px_rgba(0,0,0,0.55)] backdrop-blur-xl ' +
              (t.tone === 'good'
                ? 'border-[#FFD86B]/30'
                : t.tone === 'warn'
                  ? 'border-[#C8A8BC]/30'
                  : 'border-white/10')
            }
          >
            <div className="font-semibold text-white">{t.title}</div>
            {t.detail ? <div className="mt-0.5 text-xs text-[#B8B8D0]">{t.detail}</div> : null}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
