import { Sparkles } from 'lucide-react';

export default function GlowBadge({ label, color }: { label: string; color?: string }) {
  const c = color || '#C8A8BC';
  return (
    <div
      className="group relative overflow-hidden rounded-2xl border border-white/10 bg-[#16182D]/80 px-3 py-2 text-xs text-white shadow-[0_0_0_1px_rgba(255,255,255,0.06)]"
      style={{ boxShadow: `0 0 0 1px rgba(255,255,255,0.06), 0 0 28px ${c}22` }}
    >
      <div className="relative z-10 flex items-center gap-2">
        <div className="grid h-7 w-7 place-items-center rounded-xl bg-white/5" style={{ boxShadow: `0 0 18px ${c}30` }}>
          <Sparkles className="h-4 w-4" style={{ color: c }} />
        </div>
        <div className="font-semibold">{label}</div>
      </div>
      <div className="absolute -inset-12 opacity-0 transition group-hover:opacity-100" style={{ background: `radial-gradient(circle at 40% 30%, ${c}40, transparent 55%)` }} />
    </div>
  );
}
