import { type ReactNode } from 'react';

export default function Card({ title, right, children }: { title?: string; right?: ReactNode; children: ReactNode }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-[#1C1F3A]/85 p-4 shadow-[0_0_0_1px_rgba(80,53,153,0.18),0_16px_60px_rgba(0,0,0,0.45)] backdrop-blur-xl">
      {(title || right) && (
        <div className="mb-3 flex items-center justify-between gap-3">
          {title ? <div className="text-sm font-semibold text-white">{title}</div> : <div />}
          {right}
        </div>
      )}
      {children}
    </div>
  );
}
