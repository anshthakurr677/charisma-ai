import { clamp } from '../lib/format';

export default function ProgressBar({ value, max }: { value: number; max: number }) {
  const pct = max <= 0 ? 0 : clamp((value / max) * 100, 0, 100);
  return (
    <div className="h-3 w-full rounded-full bg-black/35 ring-1 ring-white/10 overflow-hidden">
      <div
        className="h-full rounded-full bg-[linear-gradient(90deg,#503599_0%,#976A9D_55%,#FFD86B_100%)] shadow-[0_0_24px_rgba(255,216,107,0.18)] transition-[width] duration-500"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
