import { NavLink, Outlet } from 'react-router-dom';

const tabs = [
  { to: '/admin', label: 'Dashboard' },
  { to: '/admin/users', label: 'Users' },
  { to: '/admin/missions', label: 'Missions' },
  { to: '/admin/challenges', label: 'Challenges' },
  { to: '/admin/analytics', label: 'Analytics' },
];

export default function AdminShell() {
  return (
    <div className="mx-auto max-w-[1040px] px-5 pb-16 pt-10">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-xs font-semibold tracking-wider text-[#6B6C85]">CHARISMA AI</div>
          <div className="text-3xl font-black text-white">Admin</div>
          <div className="mt-1 text-sm text-[#B8B8D0]">Manage missions, challenges and platform stats.</div>
        </div>
        <a href="/" className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10">
          Back to site
        </a>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {tabs.map((t) => (
          <NavLink
            key={t.to}
            to={t.to}
            end={t.to === '/admin'}
            className={({ isActive }) =>
              'rounded-2xl px-4 py-2 text-sm font-semibold transition ' +
              (isActive
                ? 'bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] text-white'
                : 'border border-white/10 bg-white/5 text-[#B8B8D0] hover:bg-white/10')
            }
          >
            {t.label}
          </NavLink>
        ))}
      </div>

      <div className="mt-6">
        <Outlet />
      </div>
    </div>
  );
}
