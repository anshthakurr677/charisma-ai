import { useEffect, useState } from 'react';
import Card from '../../components/Card';
import { api } from '../../lib/api';

export default function AdminUsers() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<any[]>([]);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const data = await api.users.list();
      setUsers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  return (
    <Card title="Users" right={<div className="text-xs text-[#B8B8D0]">{users.length}</div>}>
      {loading ? (
        <div className="h-28 rounded-2xl bg-white/5 animate-pulse" />
      ) : (
        <div className="grid gap-2">
          {users.map((u) => (
            <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-white/10 bg-[#16182D]/65 px-4 py-3">
              <div>
                <div className="text-sm font-semibold text-white">{u.username}</div>
                <div className="text-xs text-[#B8B8D0]">{u.email}</div>
              </div>
              <div className="text-xs text-[#B8B8D0]">Lvl {u.level} • XP {u.xp} • Streak {u.streak}</div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
