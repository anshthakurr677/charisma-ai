import { useEffect, useMemo, useState } from 'react';
import Card from '../../components/Card';

export default function AdminAnalytics() {
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<any[]>([]);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/xp-events');
      const data = await res.json();
      setEvents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const totals = useMemo(() => {
    return events.reduce(
      (acc, e) => {
        acc.xp += Number(e.xp_delta || 0);
        acc.count += 1;
        return acc;
      },
      { xp: 0, count: 0 }
    );
  }, [events]);

  return (
    <div className="grid gap-4">
      <Card title="Analytics" right={<div className="text-xs text-[#B8B8D0]">XP events</div>}>
        {loading ? (
          <div className="h-24 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <Metric label="Total XP awarded" value={totals.xp} />
            <Metric label="Events" value={totals.count} />
          </div>
        )}
      </Card>

      <Card title="Recent events">
        {loading ? (
          <div className="h-28 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="grid gap-2">
            {events.slice(0, 30).map((e) => (
              <div key={e.id} className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-white/10 bg-[#16182D]/65 px-4 py-3">
                <div>
                  <div className="text-sm font-semibold text-white">{e.source}</div>
                  <div className="text-xs text-[#6B6C85]">{new Date(e.created_at).toLocaleString()}</div>
                </div>
                <div className="text-sm font-black text-[#FFD86B]">+{e.xp_delta} XP</div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
      <div className="text-xs font-semibold text-[#6B6C85]">{label}</div>
      <div className="mt-1 text-xl font-black text-white">{value}</div>
    </div>
  );
}
