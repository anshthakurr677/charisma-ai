import { useEffect, useState } from 'react';
import Card from '../../components/Card';
import Button from '../../components/Button';

export default function AdminChallenges() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [tier, setTier] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [xp, setXp] = useState(250);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/challenges');
      const data = await res.json();
      setItems(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const add = async () => {
    const res = await fetch('/api/challenges', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description: desc, tier, xp_reward: xp, active: true }),
    });
    if (res.ok) {
      setTitle('');
      setDesc('');
      await fetchItems();
    }
  };

  const remove = async (id: number) => {
    const res = await fetch('/api/challenges', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    if (res.ok) fetchItems();
  };

  return (
    <div className="grid gap-4">
      <Card title="Add challenge">
        <div className="grid gap-3">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Challenge title"
            className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
          />
          <input
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            placeholder="Short description"
            className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
          />
          <div className="grid gap-3 sm:grid-cols-3">
            <select
              value={tier}
              onChange={(e) => setTier(e.target.value as any)}
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
            >
              <option value="beginner">beginner</option>
              <option value="intermediate">intermediate</option>
              <option value="advanced">advanced</option>
            </select>
            <input
              value={xp}
              onChange={(e) => setXp(Number(e.target.value))}
              type="number"
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
            />
          </div>
        </div>
        <div className="mt-3">
          <Button onClick={add} disabled={!title.trim()}>
            Add
          </Button>
        </div>
      </Card>

      <Card title="Challenge list" right={<div className="text-xs text-[#B8B8D0]">{items.length}</div>}>
        {loading ? (
          <div className="h-28 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="grid gap-2">
            {items.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-3xl border border-white/10 bg-[#16182D]/65 px-4 py-3">
                <div>
                  <div className="text-sm font-semibold text-white">{c.title}</div>
                  <div className="text-xs text-[#B8B8D0]">{c.tier} • +{c.xp_reward} XP</div>
                  <div className="text-xs text-[#6B6C85] mt-0.5">{c.description}</div>
                </div>
                <button
                  onClick={() => remove(c.id)}
                  className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white transition hover:bg-white/10"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
