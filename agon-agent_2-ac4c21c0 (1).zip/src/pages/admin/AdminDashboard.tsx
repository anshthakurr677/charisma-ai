import { useEffect, useState } from 'react';
import Card from '../../components/Card';
import { api } from '../../lib/api';

export default function AdminDashboard() {
  const [loading, setLoading] = useState(true);
  const [m, setM] = useState<any | null>(null);

  const fetchMetrics = async () => {
    setLoading(true);
    try {
      const data = await api.admin.metrics();
      setM(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  return (
    <div className="grid gap-4">
      <Card title="Platform Metrics" right={<div className="text-xs text-[#B8B8D0]">Live DB</div>}>
        {loading || !m ? (
          <div className="h-20 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Metric label="Total Users" value={m.totalUsers} />
            <Metric label="Active Users" value={m.activeUsers} />
            <Metric label="Missions Completed" value={m.totalMissionsCompleted} />
            <Metric label="Revenue (INR)" value={m.revenueINR} />
          </div>
        )}
      </Card>

      <Card title="Admin capabilities">
        <ul className="grid gap-2 text-sm text-[#B8B8D0]">
          {['Add/Edit/Delete Missions', 'Add/Edit/Delete Challenges', 'Manage Users & Premium plans', 'Announcements (coming soon)'].map((x) => (
            <li key={x} className="flex gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-[#C8A8BC]" />
              <span>{x}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
      <div className="text-xs font-semibold text-[#6B6C85]">{label}</div>
      <div className="mt-1 text-xl font-black text-white">{value}</div>
    </div>
  );
}
