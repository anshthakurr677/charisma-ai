import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import { useEffect } from 'react';

export default function AppShell() {
  const loc = useLocation();
  const nav = useNavigate();

  useEffect(() => {
    // If user hasn't registered, create a local session by redirecting.
    const id = localStorage.getItem('charisma_ai_user_id');
    if (!id) nav('/register');
  }, [nav]);

  const title =
    loc.pathname.includes('/missions')
      ? 'Missions'
      : loc.pathname.includes('/challenges')
        ? 'Challenges'
        : loc.pathname.includes('/mentor')
          ? 'AI Mentor'
          : loc.pathname.includes('/progress')
            ? 'Progress'
            : loc.pathname.includes('/profile')
              ? 'Profile'
              : 'Home';

  return (
    <div className="mx-auto min-h-dvh max-w-[560px] px-5 pb-28 pt-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <div className="text-xs font-semibold tracking-wider text-[#6B6C85]">CHARISMA AI</div>
          <div className="text-xl font-black text-white">{title}</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-[#B8B8D0]">SaaS-ready</div>
      </div>
      <Outlet />
      <BottomNav />
    </div>
  );
}
