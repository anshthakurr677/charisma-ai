import { useMemo, useState } from 'react';
import Card from '../components/Card';
import { receiveResponse, sendMessage, type ChatMessage } from '../lib/mentor';
import { Send } from 'lucide-react';

export default function Mentor() {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const seed: ChatMessage[] = [
      { id: crypto.randomUUID(), role: 'mentor', text: 'I’m your AI mentor. Ask me about confidence, communication, discipline, or social skills.', ts: Date.now() },
    ];
    return seed;
  });
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);

  const limit = useMemo(() => {
    // UI-only limit; backend-ready.
    return 5;
  }, []);

  const userMessages = messages.filter((m) => m.role === 'user').length;

  const onSend = async () => {
    if (!text.trim()) return;
    if (userMessages >= limit) return;
    setSending(true);
    try {
      const u = await sendMessage(text.trim());
      setMessages((p) => [...p, u]);
      setText('');
      const r = await receiveResponse(u.text);
      setMessages((p) => [...p, r]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="grid gap-4">
      <Card title="AI Mentor" right={<div className="text-xs text-[#B8B8D0]">{Math.max(0, limit - userMessages)} left today</div>}>
        <div className="max-h-[52vh] overflow-auto rounded-3xl border border-white/10 bg-black/20 p-3">
          <div className="grid gap-2">
            {messages.map((m) => (
              <Bubble key={m.id} role={m.role} text={m.text} />
            ))}
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') onSend();
            }}
            className="h-11 flex-1 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
            placeholder="Ask about confidence…"
          />
          <button
            disabled={sending || !text.trim() || userMessages >= limit}
            onClick={onSend}
            className="grid h-11 w-11 place-items-center rounded-2xl bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] text-white transition hover:brightness-110 disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>

        {userMessages >= limit ? (
          <div className="mt-3 rounded-2xl border border-[#FFD86B]/25 bg-[linear-gradient(135deg,rgba(255,216,107,0.12),rgba(255,179,71,0.08))] p-3 text-sm text-white">
            Free limit reached. Upgrade to Premium for unlimited mentor messages.
          </div>
        ) : null}
      </Card>
    </div>
  );
}

function Bubble({ role, text }: { role: 'user' | 'mentor'; text: string }) {
  const isUser = role === 'user';
  return (
    <div className={isUser ? 'flex justify-end' : 'flex justify-start'}>
      <div
        className={
          'max-w-[85%] rounded-3xl px-4 py-3 text-sm shadow-[0_16px_50px_rgba(0,0,0,0.35)] ' +
          (isUser
            ? 'bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] text-white'
            : 'border border-white/10 bg-white/5 text-[#B8B8D0]')
        }
      >
        {text}
      </div>
    </div>
  );
}
