import Card from '../components/Card';
import { formatINR } from '../lib/format';
import { Crown, Sparkles } from 'lucide-react';
import Button from '../components/Button';
import { api } from '../lib/api';
import { useToasts } from '../components/ToastHost';

export default function Premium() {
  const toasts = useToasts();
  const userId = localStorage.getItem('charisma_ai_user_id') || '';

  const upgrade = async (isYearly: boolean) => {
    // DB-ready: toggle premium flag (subscription billing comes later)
    try {
      await api.users.update({ id: userId, premium_status: true });
      toasts.push({ title: 'Premium unlocked', detail: isYearly ? 'Yearly plan activated.' : 'Monthly plan activated.', tone: 'good' });
    } catch (err: any) {
      toasts.push({ title: 'Upgrade failed', detail: err.message, tone: 'warn' });
    }
  };

  return (
    <div className="grid gap-4">
      <div className="rounded-[32px] border border-[#FFD86B]/25 bg-[linear-gradient(135deg,rgba(255,216,107,0.20),rgba(255,179,71,0.08))] p-6 shadow-[0_0_80px_rgba(255,216,107,0.14)]">
        <div className="inline-flex items-center gap-2 rounded-2xl bg-black/25 px-3 py-2 text-xs font-semibold text-[#FFD86B]">
          <Crown className="h-4 w-4" /> PREMIUM
        </div>
        <div className="mt-3 text-3xl font-black text-white">Gold Mode: Unlimited Growth</div>
        <div className="mt-2 max-w-xl text-sm text-[#B8B8D0]">
          Unlimited mentor messages, advanced challenges, XP multiplier, premium badge, ad-free experience and future analytics.
        </div>
      </div>

      <Card title="Plans">
        <div className="grid gap-3 sm:grid-cols-2">
          <Plan
            title="Monthly"
            price={formatINR(99)}
            subtitle="Perfect to test drive Premium"
            cta="Upgrade"
            onClick={() => upgrade(false)}
          />
          <Plan
            title="Yearly"
            price={formatINR(899)}
            subtitle="Best value — commit to the glow up"
            cta="Upgrade"
            highlight
            onClick={() => upgrade(true)}
          />
        </div>
      </Card>

      <Card title="Premium perks">
        <ul className="grid gap-2 text-sm text-[#B8B8D0]">
          {[
            'Unlimited AI mentor messages',
            'Advanced challenges + special missions',
            'XP multiplier (coming soon)',
            'Premium badge + profile glow',
            'Advanced analytics (coming soon)',
            'Ad-free experience',
          ].map((x) => (
            <li key={x} className="flex gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-[#FFD86B]" />
              <span>{x}</span>
            </li>
          ))}
        </ul>
      </Card>

      <a href="/app" className="text-center text-sm font-semibold text-white hover:underline">
        Back to app
      </a>
    </div>
  );
}

function Plan({
  title,
  price,
  subtitle,
  cta,
  highlight,
  onClick,
}: {
  title: string;
  price: string;
  subtitle: string;
  cta: string;
  highlight?: boolean;
  onClick: () => void;
}) {
  return (
    <div
      className={
        'rounded-3xl border p-4 ' +
        (highlight
          ? 'border-[#FFD86B]/30 bg-[linear-gradient(135deg,rgba(255,216,107,0.14),rgba(255,179,71,0.07))] shadow-[0_0_60px_rgba(255,216,107,0.10)]'
          : 'border-white/10 bg-white/5')
      }
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-white">{title}</div>
          <div className="mt-1 text-xs text-[#B8B8D0]">{subtitle}</div>
        </div>
        {highlight ? (
          <div className="inline-flex items-center gap-2 rounded-2xl bg-black/25 px-3 py-2 text-xs font-semibold text-[#FFD86B]">
            <Sparkles className="h-4 w-4" /> Best
          </div>
        ) : null}
      </div>
      <div className="mt-3 text-3xl font-black text-white">{price}</div>
      <div className="mt-3">
        <Button onClick={onClick} className="w-full">
          {cta}
        </Button>
      </div>
    </div>
  );
}
