import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import { api } from '../lib/api';

export default function Register() {
  const nav = useNavigate();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (username.trim().length < 3) throw new Error('Username must be at least 3 characters.');
      if (!email.includes('@')) throw new Error('Enter a valid email.');
      if (password.length < 6) throw new Error('Password must be at least 6 characters.');
      if (password !== confirm) throw new Error('Passwords do not match.');

      const user = await api.users.create({ username: username.trim(), email: email.trim().toLowerCase() });
      localStorage.setItem('charisma_ai_user_id', user.id);
      localStorage.setItem('charisma_ai_email', user.email);
      nav('/app');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-[560px] px-5 pb-28 pt-10">
      <div className="mb-6">
        <div className="text-2xl font-black text-white">Create your account</div>
        <div className="mt-1 text-sm text-[#B8B8D0]">Start with missions. Earn XP today.</div>
      </div>
      <Card>
        <form onSubmit={onSubmit} className="grid gap-3">
          <label className="grid gap-1">
            <span className="text-xs font-semibold text-[#B8B8D0]">Username</span>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              placeholder="LegendInProgress"
            />
          </label>
          <label className="grid gap-1">
            <span className="text-xs font-semibold text-[#B8B8D0]">Email</span>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              placeholder="you@domain.com"
            />
          </label>
          <label className="grid gap-1">
            <span className="text-xs font-semibold text-[#B8B8D0]">Password</span>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              placeholder="••••••••"
            />
          </label>
          <label className="grid gap-1">
            <span className="text-xs font-semibold text-[#B8B8D0]">Confirm password</span>
            <input
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              type="password"
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              placeholder="••••••••"
            />
          </label>
          {error ? <div className="text-sm text-[#FFD86B]">{error}</div> : null}
          <Button disabled={loading} type="submit">
            {loading ? 'Creating…' : 'Create account'}
          </Button>
          <div className="text-center text-sm text-[#B8B8D0]">
            Already have an account?{' '}
            <Link to="/login" className="font-semibold text-white hover:underline">
              Login
            </Link>
          </div>
        </form>
      </Card>
    </div>
  );
}
