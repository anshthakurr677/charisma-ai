import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      // UI-only auth for now; backend-ready.
      // In a future iteration, connect Supabase Auth or another provider.
      if (!email.includes('@') || password.length < 6) throw new Error('Enter a valid email + password (min 6 chars).');
      localStorage.setItem('charisma_ai_email', email);
      nav('/app');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-[560px] px-5 pb-28 pt-10">
      <div className="mb-6">
        <div className="text-2xl font-black text-white">Welcome back</div>
        <div className="mt-1 text-sm text-[#B8B8D0]">Log in to continue your streak.</div>
      </div>
      <Card>
        <form onSubmit={onSubmit} className="grid gap-3">
          <label className="grid gap-1">
            <span className="text-xs font-semibold text-[#B8B8D0]">Email</span>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              placeholder="you@domain.com"
            />
          </label>
          <label className="grid gap-1">
            <span className="text-xs font-semibold text-[#B8B8D0]">Password</span>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              placeholder="••••••••"
            />
          </label>
          {error ? <div className="text-sm text-[#FFD86B]">{error}</div> : null}
          <Button disabled={loading} type="submit">
            {loading ? 'Logging in…' : 'Login'}
          </Button>

          <button
            type="button"
            onClick={() => {
              // backend-ready placeholder
              window.open('https://accounts.google.com', 'google-auth', 'width=500,height=600');
            }}
            className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10"
          >
            Continue with Google
          </button>

          <div className="text-center text-sm text-[#B8B8D0]">
            New here?{' '}
            <Link to="/register" className="font-semibold text-white hover:underline">
              Create account
            </Link>
          </div>
        </form>
      </Card>
    </div>
  );
}
