import { Link } from 'react-router-dom';
import { ArrowRight, Brain, Crown, Flame, Sparkles, Target } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';

export default function Landing() {
  return (
    <div className="mx-auto max-w-[1040px] px-5 pb-28 pt-10">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-2xl bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] shadow-[0_0_30px_rgba(151,106,157,0.35)]">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="text-sm font-semibold text-white">Charisma AI</div>
            <div className="text-xs text-[#B8B8D0]">Level up your personality</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/login"
            className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10"
          >
            Login
          </Link>
          <Link
            to="/register"
            className="rounded-2xl bg-[linear-gradient(135deg,#FFD86B_0%,#FFB347_100%)] px-4 py-2 text-sm font-semibold text-black transition hover:brightness-110"
          >
            Get Premium
          </Link>
        </div>
      </header>

      <section className="mt-12 grid gap-6 lg:grid-cols-2 lg:items-center">
        <div>
          <h1 className="text-balance text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-5xl">
            Become The Most Charismatic Version Of Yourself
          </h1>
          <p className="mt-4 max-w-xl text-pretty text-base text-[#B8B8D0] sm:text-lg">
            Charisma AI is a gamified personality development platform that builds confidence, communication, discipline and social skills
            through daily missions, challenges and an AI mentor. Earn XP, keep streaks, unlock achievements — and become unstoppable.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Link to="/register" className="w-full sm:w-auto">
              <Button className="w-full">Start Your Growth Journey</Button>
            </Link>
            <Link
              to="/app/missions"
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-center text-sm font-semibold text-white transition hover:bg-white/10 sm:w-auto"
            >
              Explore Missions
            </Link>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-3 max-w-md">
            <Stat label="XP" value="+20 / +50 / +100" />
            <Stat label="Streak" value="Daily flame" />
            <Stat label="Mentor" value="24/7" />
          </div>
        </div>

        <div className="relative">
          <div className="absolute -inset-2 rounded-[28px] bg-[linear-gradient(135deg,rgba(80,53,153,0.35),rgba(151,106,157,0.22),rgba(255,216,107,0.12))] blur-2xl" />
          <div className="relative rounded-[28px] border border-white/10 bg-[#16182D]/70 p-5 shadow-[0_20px_80px_rgba(0,0,0,0.55)] backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold text-white">Today’s Missions</div>
              <div className="rounded-full bg-white/5 px-3 py-1 text-xs text-[#B8B8D0]">Live demo</div>
            </div>
            <div className="mt-4 grid gap-3">
              <MiniMission icon={Target} title="Maintain eye contact" xp="+50 XP" />
              <MiniMission icon={Flame} title="Talk to a new person" xp="+20 XP" />
              <MiniMission icon={Brain} title="Ask the AI mentor" xp="+10 XP" />
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <Card title="Level up">
                <div className="text-xs text-[#B8B8D0]">Unlock challenges as you climb.</div>
                <div className="mt-3 inline-flex items-center gap-2 rounded-2xl bg-white/5 px-3 py-2 text-sm text-white">
                  <Sparkles className="h-4 w-4" /> Level 5: Charismatic
                </div>
              </Card>
              <Card title="Premium">
                <div className="text-xs text-[#B8B8D0]">Unlimited mentor + advanced analytics.</div>
                <div className="mt-3 inline-flex items-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#FFD86B_0%,#FFB347_100%)] px-3 py-2 text-sm font-semibold text-black">
                  <Crown className="h-4 w-4" /> Upgrade
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section className="mt-12 grid gap-4 lg:grid-cols-3">
        <InfoCard
          title="How It Works"
          items={[
            'Get 3–5 daily missions (more with Premium)',
            'Complete challenges to earn massive XP',
            'Chat with your AI mentor to refine your vibe',
          ]}
        />
        <InfoCard
          title="Features"
          items={['XP, Levels, Streaks, Achievements', 'Mobile-first SaaS dashboard UI', 'Admin panel for missions & analytics']}
        />
        <InfoCard
          title="Gamification System"
          items={['Easy +20 XP • Medium +50 XP • Hard +100 XP', 'Daily login bonus +10 XP', 'Special challenge +250 XP']}
        />
      </section>

      <section className="mt-12 grid gap-4 lg:grid-cols-2">
        <Card title="Testimonials" right={<div className="text-xs text-[#B8B8D0]">Community</div>}>
          <div className="grid gap-3">
            <Quote who="Aarav" text="The streak + missions turned my anxiety into action. It feels like a game — but it\'s my real life." />
            <Quote who="Meera" text="The AI mentor gives me scripts for conversations. I sound confident now." />
            <Quote who="Kabir" text="Level-ups made discipline addictive. I\'m actually consistent." />
          </div>
        </Card>
        <Card title="Pricing">
          <div className="grid gap-3">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-sm font-semibold text-white">Free</div>
              <div className="mt-1 text-xs text-[#B8B8D0]">3 daily missions • limited challenges • 5 mentor questions/day</div>
            </div>
            <div className="rounded-3xl border border-[#FFD86B]/25 bg-[linear-gradient(135deg,rgba(255,216,107,0.12),rgba(255,179,71,0.08))] p-4 shadow-[0_0_40px_rgba(255,216,107,0.12)]">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold text-white">Premium</div>
                  <div className="mt-1 text-xs text-[#B8B8D0]">Unlimited mentor • advanced challenges • XP multiplier</div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-black text-white">₹99</div>
                  <div className="text-xs text-[#B8B8D0]">/month</div>
                </div>
              </div>
            </div>
            <Link to="/premium" className="group mt-1 inline-flex items-center justify-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#FFD86B_0%,#FFB347_100%)] px-4 py-3 text-sm font-semibold text-black transition hover:brightness-110">
              View plans <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </Link>
          </div>
        </Card>
      </section>

      <section className="mt-12">
        <div className="rounded-[32px] border border-white/10 bg-[linear-gradient(135deg,rgba(80,53,153,0.35),rgba(151,106,157,0.18))] p-6 shadow-[0_20px_80px_rgba(0,0,0,0.55)]">
          <div className="text-xs font-semibold tracking-wider text-[#C8A8BC]">CALL TO ACTION</div>
          <div className="mt-2 text-2xl font-black text-white sm:text-3xl">Your next level is one mission away.</div>
          <div className="mt-2 max-w-2xl text-sm text-[#B8B8D0]">
            Start free. Earn XP today. Upgrade when you want advanced missions and unlimited mentorship.
          </div>
          <div className="mt-4 flex flex-col gap-3 sm:flex-row">
            <Link to="/register" className="w-full sm:w-auto">
              <Button className="w-full">Create account</Button>
            </Link>
            <Link
              to="/app"
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-center text-sm font-semibold text-white transition hover:bg-white/10 sm:w-auto"
            >
              Try the dashboard
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2">
      <div className="text-[10px] font-semibold tracking-wider text-[#6B6C85]">{label}</div>
      <div className="mt-1 text-xs font-semibold text-white">{value}</div>
    </div>
  );
}

function MiniMission({ icon: Icon, title, xp }: { icon: any; title: string; xp: string }) {
  return (
    <div className="group flex items-center justify-between rounded-3xl border border-white/10 bg-[#1C1F3A]/70 px-4 py-3 transition hover:shadow-[0_0_40px_rgba(151,106,157,0.16)]">
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-2xl bg-white/5">
          <Icon className="h-5 w-5 text-[#C8A8BC]" />
        </div>
        <div>
          <div className="text-sm font-semibold text-white">{title}</div>
          <div className="text-xs text-[#B8B8D0]">Quick win</div>
        </div>
      </div>
      <div className="text-xs font-semibold text-[#FFD86B]">{xp}</div>
    </div>
  );
}

function InfoCard({ title, items }: { title: string; items: string[] }) {
  return (
    <Card title={title}>
      <ul className="grid gap-2 text-sm text-[#B8B8D0]">
        {items.map((x) => (
          <li key={x} className="flex gap-2">
            <span className="mt-1 h-1.5 w-1.5 rounded-full bg-[#C8A8BC]" />
            <span>{x}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function Quote({ who, text }: { who: string; text: string }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
      <div className="text-sm text-white">“{text}”</div>
      <div className="mt-2 text-xs font-semibold text-[#C8A8BC]">— {who}</div>
    </div>
  );
}
