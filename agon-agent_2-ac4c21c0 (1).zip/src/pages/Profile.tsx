import { useEffect, useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import { api } from '../lib/api';

export default function Profile() {
  const userId = localStorage.getItem('charisma_ai_user_id') || '';
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any | null>(null);
  const [name, setName] = useState('');

  const fetchUser = async () => {
    setLoading(true);
    try {
      const u = await api.progress.get(userId);
      setUser(u.user);
      setName(u.user.username);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    const updated = await api.users.update({ id: userId, username: name });
    setUser(updated);
  };

  return (
    <div className="grid gap-4">
      <Card title="Profile">
        {loading || !user ? (
          <div className="h-24 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="grid gap-3">
            <div className="grid gap-1">
              <div className="text-xs font-semibold text-[#B8B8D0]">Username</div>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-11 rounded-2xl border border-white/10 bg-black/25 px-3 text-sm text-white outline-none focus:ring-2 focus:ring-[#976A9D]/60"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
                <div className="text-xs font-semibold text-[#6B6C85]">Level</div>
                <div className="mt-1 text-xl font-black text-white">{user.level}</div>
              </div>
              <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
                <div className="text-xs font-semibold text-[#6B6C85]">XP</div>
                <div className="mt-1 text-xl font-black text-white">{user.xp}</div>
              </div>
              <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
                <div className="text-xs font-semibold text-[#6B6C85]">Streak</div>
                <div className="mt-1 text-xl font-black text-white">{user.streak}</div>
              </div>
              <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
                <div className="text-xs font-semibold text-[#6B6C85]">Completed</div>
                <div className="mt-1 text-xl font-black text-white">{user.completed_missions}</div>
              </div>
            </div>

            <Button onClick={save}>Edit profile</Button>
            <button
              onClick={() => {
                localStorage.removeItem('charisma_ai_user_id');
                window.location.href = '/';
              }}
              className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10"
            >
              Sign out
            </button>
          </div>
        )}
      </Card>
    </div>
  );
}
