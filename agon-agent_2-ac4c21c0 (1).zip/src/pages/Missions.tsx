import { useEffect, useMemo, useState } from 'react';
import Card from '../components/Card';
import { api } from '../lib/api';
import { useToasts } from '../components/ToastHost';

export default function Missions() {
  const toasts = useToasts();
  const userId = localStorage.getItem('charisma_ai_user_id') || '';
  const [loading, setLoading] = useState(true);
  const [missions, setMissions] = useState<any[]>([]);
  const [filter, setFilter] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');

  const fetchItems = async () => {
    setLoading(true);
    try {
      const data = await api.missions.list({ active: true });
      setMissions(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const filtered = useMemo(() => {
    if (filter === 'all') return missions;
    return missions.filter((m) => m.difficulty === filter);
  }, [missions, filter]);

  const complete = async (mission_id: number) => {
    try {
      await api.completeMission({ user_id: userId, mission_id });
      toasts.push({ title: 'Mission completed', detail: 'XP added to your profile.', tone: 'good' });
    } catch (err: any) {
      toasts.push({ title: 'Could not complete', detail: err.message, tone: 'warn' });
    }
  };

  return (
    <div className="grid gap-4">
      <Card title="Daily Missions">
        <div className="flex flex-wrap gap-2">
          {(['all', 'easy', 'medium', 'hard'] as const).map((k) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={
                'rounded-2xl px-3 py-2 text-xs font-semibold transition ' +
                (filter === k
                  ? 'bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] text-white'
                  : 'border border-white/10 bg-white/5 text-[#B8B8D0] hover:bg-white/10')
              }
            >
              {k.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="mt-4 text-sm text-[#B8B8D0]">Easy +20 XP • Medium +50 XP • Hard +100 XP</div>
      </Card>

      <Card title="Mission Library" right={<div className="text-xs text-[#B8B8D0]">{filtered.length} missions</div>}>
        {loading ? (
          <div className="grid gap-3">
            <div className="h-16 rounded-2xl bg-white/5 animate-pulse" />
            <div className="h-16 rounded-2xl bg-white/5 animate-pulse" />
            <div className="h-16 rounded-2xl bg-white/5 animate-pulse" />
          </div>
        ) : (
          <div className="grid gap-3">
            {filtered.map((m) => (
              <div key={m.id} className="rounded-3xl border border-white/10 bg-[#16182D]/65 px-4 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-white">{m.title}</div>
                    <div className="mt-0.5 text-xs text-[#B8B8D0]">
                      Difficulty: <span className="font-semibold text-white">{m.difficulty}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-[#6B6C85]">Reward</div>
                    <div className="text-sm font-black text-[#FFD86B]">+{m.xp_reward} XP</div>
                  </div>
                </div>
                <div className="mt-3">
                  <button
                    onClick={() => complete(m.id)}
                    className="w-full rounded-2xl bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] px-4 py-2.5 text-sm font-semibold text-white transition hover:brightness-110"
                  >
                    Complete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
