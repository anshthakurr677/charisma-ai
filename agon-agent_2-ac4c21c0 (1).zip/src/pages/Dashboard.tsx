import { useEffect, useMemo, useState } from 'react';
import Card from '../components/Card';
import ProgressBar from '../components/ProgressBar';
import { api } from '../lib/api';
import { levelMeta } from '../lib/levels';
import Button from '../components/Button';
import { Flame, Plus, Sparkles, Target } from 'lucide-react';
import { useToasts } from '../components/ToastHost';

export default function Dashboard() {
  const toasts = useToasts();
  const userId = localStorage.getItem('charisma_ai_user_id') || '';
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any | null>(null);
  const [computed, setComputed] = useState<any | null>(null);
  const [daily, setDaily] = useState<any[]>([]);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const p = await api.progress.get(userId);
      setUser(p.user);
      setComputed(p.computed);
      const d = await api.daily.list(userId);
      setDaily(d);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!userId) return;
    fetchAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const meta = useMemo(() => levelMeta(user?.level ?? 1), [user?.level]);

  const complete = async (mission_id: number) => {
    try {
      const res = await api.completeMission({ user_id: userId, mission_id });
      if (res?.streakRewards?.length) {
        toasts.push({ title: 'Streak reward unlocked', detail: `Bonus +${res.streakRewards[0].amount} XP`, tone: 'good' });
      } else {
        toasts.push({ title: 'Mission complete', detail: 'XP added. Keep going.', tone: 'good' });
      }
      await fetchAll();
    } catch (err: any) {
      toasts.push({ title: 'Could not complete mission', detail: err.message, tone: 'warn' });
    }
  };

  if (loading) {
    return (
      <div className="grid gap-4">
        <Card title="Loading…">
          <div className="h-20 rounded-2xl bg-white/5 animate-pulse" />
        </Card>
        <Card title="Today’s Missions">
          <div className="grid gap-3">
            <div className="h-16 rounded-2xl bg-white/5 animate-pulse" />
            <div className="h-16 rounded-2xl bg-white/5 animate-pulse" />
            <div className="h-16 rounded-2xl bg-white/5 animate-pulse" />
          </div>
        </Card>
      </div>
    );
  }

  if (!user) return <Card title="No user">Create an account to start.</Card>;

  const xpInto = computed?.xpIntoLevel ?? 0;
  const xpToNext = computed?.xpToNext ?? 1;

  return (
    <div className="grid gap-4">
      <Card
        title="Your Dashboard"
        right={
          <div className="inline-flex items-center gap-2 rounded-2xl bg-white/5 px-3 py-1.5 text-xs text-[#B8B8D0]">
            <Flame className="h-4 w-4 text-[#FFD86B]" /> {user.streak} day streak
          </div>
        }
      >
        <div className="grid gap-3">
          <div className="flex items-end justify-between">
            <div>
              <div className="text-2xl font-black text-white">Level {user.level}</div>
              <div className="text-sm text-[#B8B8D0]">{meta.current.name}</div>
            </div>
            <div className="text-right">
              <div className="text-xs font-semibold text-[#6B6C85]">Total XP</div>
              <div className="text-lg font-black text-white">{user.xp}</div>
            </div>
          </div>
          <ProgressBar value={xpInto} max={xpToNext} />
          <div className="flex items-center justify-between text-xs text-[#B8B8D0]">
            <div>
              {xpInto}/{xpToNext} XP to next level
            </div>
            <div className="text-[#C8A8BC] font-semibold">{meta.next.name} unlocked soon</div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-xs text-[#6B6C85] font-semibold">Completed missions</div>
              <div className="mt-1 text-xl font-black text-white">{user.completed_missions}</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-xs text-[#6B6C85] font-semibold">Premium</div>
              <div className="mt-1 text-xl font-black text-white">{user.premium_status ? 'Yes' : 'Free'}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => toasts.push({ title: 'Quick action', detail: 'Open Missions to complete one now.', tone: 'neutral' })}
              className="flex items-center justify-center gap-2"
            >
              <Target className="h-4 w-4" /> Start mission
            </Button>
            <a
              href="/premium"
              className="flex items-center justify-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#FFD86B_0%,#FFB347_100%)] px-4 py-2.5 text-sm font-semibold text-black transition hover:brightness-110"
            >
              <Sparkles className="h-4 w-4" /> Upgrade
            </a>
          </div>
        </div>
      </Card>

      <Card title="Today’s Missions" right={<div className="text-xs text-[#B8B8D0]">{daily.length} assigned</div>}>
        <div className="grid gap-3">
          {daily.map((a) => (
            <MissionRow key={a.id} title={a.missions?.title} xp={a.missions?.xp_reward} onComplete={() => complete(a.mission_id)} />
          ))}
        </div>
      </Card>

      <Card title="Quick stats">
        <div className="grid grid-cols-2 gap-3">
          <QuickStat label="Easy" value="+20 XP" />
          <QuickStat label="Medium" value="+50 XP" />
          <QuickStat label="Hard" value="+100 XP" />
          <QuickStat label="Special" value="+250 XP" />
        </div>
      </Card>
    </div>
  );
}

function QuickStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
      <div className="text-xs font-semibold text-[#6B6C85]">{label}</div>
      <div className="mt-1 text-sm font-semibold text-white">{value}</div>
    </div>
  );
}

function MissionRow({ title, xp, onComplete }: { title: string; xp: number; onComplete: () => void }) {
  const [done, setDone] = useState(false);
  return (
    <div
      className={
        'group flex items-center justify-between gap-3 rounded-3xl border border-white/10 bg-[#16182D]/65 px-4 py-3 transition ' +
        (done ? 'opacity-70' : 'hover:shadow-[0_0_44px_rgba(151,106,157,0.16)]')
      }
    >
      <div>
        <div className="text-sm font-semibold text-white">{title}</div>
        <div className="text-xs text-[#B8B8D0]">Reward: <span className="font-semibold text-[#FFD86B]">+{xp} XP</span></div>
      </div>
      <button
        disabled={done}
        onClick={async () => {
          setDone(true);
          await onComplete();
        }}
        className={
          'inline-flex items-center gap-2 rounded-2xl px-3 py-2 text-xs font-semibold transition ' +
          (done
            ? 'bg-white/5 text-[#B8B8D0]'
            : 'bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] text-white hover:brightness-110')
        }
      >
        <Plus className="h-4 w-4" /> {done ? 'Done' : 'Complete'}
      </button>
    </div>
  );
}
