import { useEffect, useMemo, useState } from 'react';
import Card from '../components/Card';
import { api } from '../lib/api';

export default function Challenges() {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<any[]>([]);
  const [tier, setTier] = useState<'all' | 'beginner' | 'intermediate' | 'advanced'>('all');

  const fetchItems = async () => {
    setLoading(true);
    try {
      const data = await api.challenges.list({ active: true });
      setItems(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const filtered = useMemo(() => {
    if (tier === 'all') return items;
    return items.filter((c) => c.tier === tier);
  }, [items, tier]);

  return (
    <div className="grid gap-4">
      <Card title="Social Confidence Challenges" right={<div className="text-xs text-[#B8B8D0]">Special +250 XP</div>}>
        <div className="flex flex-wrap gap-2">
          {(['all', 'beginner', 'intermediate', 'advanced'] as const).map((k) => (
            <button
              key={k}
              onClick={() => setTier(k)}
              className={
                'rounded-2xl px-3 py-2 text-xs font-semibold transition ' +
                (tier === k
                  ? 'bg-[linear-gradient(135deg,#503599_0%,#976A9D_100%)] text-white'
                  : 'border border-white/10 bg-white/5 text-[#B8B8D0] hover:bg-white/10')
              }
            >
              {k.toUpperCase()}
            </button>
          ))}
        </div>
      </Card>

      <Card title="Challenge Board" right={<div className="text-xs text-[#B8B8D0]">{filtered.length} available</div>}>
        {loading ? (
          <div className="grid gap-3">
            <div className="h-20 rounded-2xl bg-white/5 animate-pulse" />
            <div className="h-20 rounded-2xl bg-white/5 animate-pulse" />
          </div>
        ) : (
          <div className="grid gap-3">
            {filtered.map((c) => (
              <div key={c.id} className="rounded-3xl border border-white/10 bg-[#16182D]/65 px-4 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-white">{c.title}</div>
                    <div className="mt-1 text-xs text-[#B8B8D0]">{c.description}</div>
                    <div className="mt-2 text-xs text-[#C8A8BC] font-semibold">{c.tier.toUpperCase()}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-[#6B6C85]">Reward</div>
                    <div className="text-sm font-black text-[#FFD86B]">+{c.xp_reward} XP</div>
                  </div>
                </div>
                <div className="mt-3 text-xs text-[#B8B8D0]">Complete it in real life, then log it with your mentor (coming soon).</div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
