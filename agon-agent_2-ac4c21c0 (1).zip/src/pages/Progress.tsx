import { useEffect, useMemo, useState } from 'react';
import Card from '../components/Card';
import { api } from '../lib/api';
import ProgressBar from '../components/ProgressBar';

export default function Progress() {
  const userId = localStorage.getItem('charisma_ai_user_id') || '';
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any | null>(null);
  const [ach, setAch] = useState<any[]>([]);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const p = await api.progress.get(userId);
      const a = await api.achievements.list();
      setData(p);
      setAch(a);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const xpInto = data?.computed?.xpIntoLevel ?? 0;
  const xpToNext = data?.computed?.xpToNext ?? 1;
  const recent = useMemo(() => (data?.recentMissions ?? []).slice(0, 10), [data]);

  return (
    <div className="grid gap-4">
      <Card title="Progress Dashboard">
        {loading ? (
          <div className="h-24 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="grid gap-3">
            <div className="flex items-end justify-between">
              <div>
                <div className="text-2xl font-black text-white">Level {data.user.level}</div>
                <div className="text-sm text-[#B8B8D0]">XP: {data.user.xp}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-[#6B6C85]">Streak</div>
                <div className="text-lg font-black text-white">{data.user.streak} 🔥</div>
              </div>
            </div>
            <ProgressBar value={xpInto} max={xpToNext} />
            <div className="text-xs text-[#B8B8D0]">
              {xpInto}/{xpToNext} XP into this level
            </div>
          </div>
        )}
      </Card>

      <Card title="XP Graph (last 10 completions)" right={<div className="text-xs text-[#B8B8D0]">Backend-ready</div>}>
        {loading ? (
          <div className="h-28 rounded-2xl bg-white/5 animate-pulse" />
        ) : (
          <div className="flex items-end gap-2">
            {recent.map((r: any) => (
              <div key={r.id} className="flex-1">
                <div
                  className="w-full rounded-xl bg-[linear-gradient(180deg,#976A9D_0%,rgba(151,106,157,0.2)_100%)] shadow-[0_0_18px_rgba(151,106,157,0.22)]"
                  style={{ height: `${Math.max(10, Math.min(110, (r.xp_earned / 100) * 110))}px` }}
                  title={`${r.xp_earned} XP`}
                />
                <div className="mt-1 text-[10px] text-[#6B6C85] text-center">{String(r.day).slice(5)}</div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Achievements (unlock logic coming soon)">
        <div className="grid gap-2 sm:grid-cols-2">
          {ach.map((a) => (
            <div key={a.id} className="rounded-3xl border border-white/10 bg-[#16182D]/65 p-4">
              <div className="text-sm font-semibold text-white">{a.title}</div>
              <div className="mt-1 text-xs text-[#B8B8D0]">{a.description}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
