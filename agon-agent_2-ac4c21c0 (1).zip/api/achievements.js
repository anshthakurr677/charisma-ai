import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .order('id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { code, title, description, glow_color } = req.body;
      if (!code || !title) return res.status(400).json({ error: 'code and title required' });
      const { data, error } = await supabase
        .from('achievements')
        .insert({ code, title, description: description ?? '', glow_color: glow_color ?? '#C8A8BC' })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, title, description, glow_color } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = {};
      if (typeof title === 'string') patch.title = title;
      if (typeof description === 'string') patch.description = description;
      if (typeof glow_color === 'string') patch.glow_color = glow_color;

      const { data, error } = await supabase
        .from('achievements')
        .update(patch)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('achievements').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
