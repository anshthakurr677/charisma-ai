import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, email } = req.query;
      let q = supabase.from('users').select('*').order('created_at', { ascending: false });
      if (id) q = q.eq('id', id);
      if (email) q = q.eq('email', email);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { username, email } = req.body;
      if (!username || !email) return res.status(400).json({ error: 'username and email required' });

      const { data, error } = await supabase
        .from('users')
        .insert({ username, email })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, username, premium_status } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = {};
      if (typeof username === 'string') patch.username = username;
      if (typeof premium_status === 'boolean') patch.premium_status = premium_status;

      const { data, error } = await supabase
        .from('users')
        .update(patch)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('users').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
