import supabase from './_supabase.js';

function ymd(date = new Date()) {
  const d = new Date(date);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const da = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${da}`;
}

function computeLevel(xp) {
  const floors = [0, 0, 100, 250, 450, 700, 1000, 1350, 1750, 2200, 2700];
  let level = 1;
  for (let i = 2; i < floors.length; i++) if (xp >= floors[i]) level = i;
  return level;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { user_id, mission_id } = req.body;
      if (!user_id || !mission_id) return res.status(400).json({ error: 'user_id and mission_id required' });

      const day = ymd();

      const { data: already, error: aErr } = await supabase
        .from('mission_completions')
        .select('*')
        .eq('user_id', user_id)
        .eq('mission_id', mission_id)
        .eq('day', day)
        .maybeSingle();
      if (aErr) throw aErr;
      if (already) return res.status(200).json({ ok: true, already: true });

      const { data: mission, error: mErr } = await supabase
        .from('missions')
        .select('*')
        .eq('id', mission_id)
        .single();
      if (mErr) throw mErr;

      const { data: user, error: uErr } = await supabase
        .from('users')
        .select('*')
        .eq('id', user_id)
        .single();
      if (uErr) throw uErr;

      // create completion row
      const { data: completion, error: cErr } = await supabase
        .from('mission_completions')
        .insert({ user_id, mission_id, day, xp_earned: mission.xp_reward })
        .select()
        .single();
      if (cErr) throw cErr;

      // streak logic: if first mission of day, streak continues
      const { data: dayCompletions, error: dErr } = await supabase
        .from('mission_completions')
        .select('id')
        .eq('user_id', user_id)
        .eq('day', day);
      if (dErr) throw dErr;

      let newStreak = user.streak ?? 0;
      let streakUpdated = false;
      if (dayCompletions.length === 1) {
        const yesterday = new Date();
        yesterday.setUTCDate(yesterday.getUTCDate() - 1);
        const yday = ymd(yesterday);
        const { data: yComps, error: yCErr } = await supabase
          .from('mission_completions')
          .select('id')
          .eq('user_id', user_id)
          .eq('day', yday)
          .limit(1);
        if (yCErr) throw yCErr;

        newStreak = (yComps && yComps.length) ? (newStreak + 1) : 1;
        streakUpdated = true;
      }

      // xp update
      let xpDelta = mission.xp_reward;
      const updatedXp = Math.max(0, (user.xp ?? 0) + xpDelta);
      const updatedLevel = computeLevel(updatedXp);

      const { data: updatedUser, error: upErr } = await supabase
        .from('users')
        .update({ xp: updatedXp, level: updatedLevel, streak: newStreak, last_active_day: day })
        .eq('id', user_id)
        .select()
        .single();
      if (upErr) throw upErr;

      const { error: logErr } = await supabase
        .from('xp_events')
        .insert({ user_id, source: 'mission', xp_delta: xpDelta, meta: { mission_id, day } });
      if (logErr) throw logErr;

      // streak rewards
      const streakRewards = [];
      if (streakUpdated && (newStreak === 3 || newStreak === 14)) {
        const bonus = newStreak === 3 ? 30 : 100;
        const bonusXp = updatedUser.xp + bonus;
        const bonusLevel = computeLevel(bonusXp);
        const { data: bonusUser, error: bErr } = await supabase
          .from('users')
          .update({ xp: bonusXp, level: bonusLevel })
          .eq('id', user_id)
          .select()
          .single();
        if (bErr) throw bErr;

        await supabase.from('xp_events').insert({ user_id, source: 'streak_bonus', xp_delta: bonus, meta: { streak: newStreak } });
        streakRewards.push({ type: 'xp', amount: bonus, streak: newStreak });
        return res.status(201).json({ ok: true, completion, user: bonusUser, streakRewards });
      }

      return res.status(201).json({ ok: true, completion, user: updatedUser, streakRewards });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
