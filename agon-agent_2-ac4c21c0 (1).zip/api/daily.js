import supabase from './_supabase.js';

function ymd(date = new Date()) {
  const d = new Date(date);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const da = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${da}`;
}

function seededPick(ids, seed, count) {
  // deterministic shuffle-ish based on seed
  let x = seed;
  const arr = [...ids];
  for (let i = arr.length - 1; i > 0; i--) {
    x = (x * 1103515245 + 12345) & 0x7fffffff;
    const j = x % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.slice(0, Math.min(count, arr.length));
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      if (!user_id) return res.status(400).json({ error: 'user_id required' });

      const today = ymd();
      const { data: existing, error: eErr } = await supabase
        .from('daily_assignments')
        .select('*, missions(*)')
        .eq('user_id', user_id)
        .eq('day', today)
        .order('id', { ascending: true });
      if (eErr) throw eErr;
      if (existing && existing.length) return res.status(200).json(existing);

      const { data: user, error: uErr } = await supabase
        .from('users')
        .select('*')
        .eq('id', user_id)
        .single();
      if (uErr) throw uErr;

      const missionCount = user.premium_status ? 5 : 3;
      const { data: missions, error: mErr } = await supabase
        .from('missions')
        .select('*')
        .eq('active', true)
        .order('id', { ascending: true });
      if (mErr) throw mErr;

      const ids = missions.map((m) => m.id);
      const seed = Number(String(user_id).replace(/\D/g, '').slice(-6) || '1337') + Number(today.replace(/-/g, ''));
      const picks = seededPick(ids, seed, missionCount);

      const rows = picks.map((mission_id) => ({ user_id, day: today, mission_id }));
      const { data: inserted, error: iErr } = await supabase
        .from('daily_assignments')
        .insert(rows)
        .select('*, missions(*)');
      if (iErr) throw iErr;

      return res.status(200).json(inserted);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
