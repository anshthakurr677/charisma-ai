import supabase from './_supabase.js';

function levelFromXp(xp) {
  const levels = [0, 0, 100, 250, 450, 700, 1000, 1350, 1750, 2200, 2700];
  let level = 1;
  for (let i = 2; i < levels.length; i++) {
    if (xp >= levels[i]) level = i;
  }
  const currentFloor = levels[level] ?? 0;
  const nextFloor = levels[level + 1] ?? (currentFloor + 600);
  return { level, currentFloor, nextFloor };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      if (!user_id) return res.status(400).json({ error: 'user_id required' });

      const { data: user, error: userErr } = await supabase
        .from('users')
        .select('*')
        .eq('id', user_id)
        .single();
      if (userErr) throw userErr;

      const { data: recentMissions, error: rmErr } = await supabase
        .from('mission_completions')
        .select('*')
        .eq('user_id', user_id)
        .order('completed_at', { ascending: false })
        .limit(30);
      if (rmErr) throw rmErr;

      const { level, currentFloor, nextFloor } = levelFromXp(user.xp);
      return res.status(200).json({
        user,
        computed: {
          level,
          currentFloor,
          nextFloor,
          xpIntoLevel: Math.max(0, user.xp - currentFloor),
          xpToNext: Math.max(1, nextFloor - currentFloor),
        },
        recentMissions,
      });
    }

    if (req.method === 'POST') {
      // award XP for an action
      const { user_id, source, xp_delta, meta } = req.body;
      if (!user_id || !source || typeof xp_delta !== 'number') {
        return res.status(400).json({ error: 'user_id, source, xp_delta required' });
      }

      const { data: user, error: uErr } = await supabase
        .from('users')
        .select('*')
        .eq('id', user_id)
        .single();
      if (uErr) throw uErr;

      const newXp = Math.max(0, (user.xp ?? 0) + xp_delta);
      const { level } = levelFromXp(newXp);

      const { data: updated, error: upErr } = await supabase
        .from('users')
        .update({ xp: newXp, level })
        .eq('id', user_id)
        .select()
        .single();
      if (upErr) throw upErr;

      const { data: log, error: lErr } = await supabase
        .from('xp_events')
        .insert({ user_id, source, xp_delta, meta: meta ?? {} })
        .select()
        .single();
      if (lErr) throw lErr;

      return res.status(201).json({ user: updated, event: log });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
