import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { count: totalUsers, error: tuErr } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true });
      if (tuErr) throw tuErr;

      const { count: activeUsers, error: auErr } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true })
        .eq('active', true);
      if (auErr) throw auErr;

      const { count: totalCompleted, error: tcErr } = await supabase
        .from('mission_completions')
        .select('*', { count: 'exact', head: true });
      if (tcErr) throw tcErr;

      const { data: subs, error: sErr } = await supabase
        .from('subscriptions')
        .select('amount_inr, status');
      if (sErr) throw sErr;

      const revenue = subs
        .filter((s) => s.status === 'active')
        .reduce((sum, s) => sum + Number(s.amount_inr || 0), 0);

      return res.status(200).json({ totalUsers: totalUsers ?? 0, activeUsers: activeUsers ?? 0, totalMissionsCompleted: totalCompleted ?? 0, revenueINR: revenue });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
