import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { difficulty, active } = req.query;
      let q = supabase.from('missions').select('*').order('id', { ascending: true });
      if (difficulty) q = q.eq('difficulty', difficulty);
      if (active === 'true') q = q.eq('active', true);
      if (active === 'false') q = q.eq('active', false);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { title, difficulty, xp_reward, active } = req.body;
      if (!title || !difficulty || !xp_reward) return res.status(400).json({ error: 'title, difficulty, xp_reward required' });
      const { data, error } = await supabase
        .from('missions')
        .insert({ title, difficulty, xp_reward, active: active ?? true })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, title, difficulty, xp_reward, active } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = {};
      if (typeof title === 'string') patch.title = title;
      if (typeof difficulty === 'string') patch.difficulty = difficulty;
      if (typeof xp_reward === 'number') patch.xp_reward = xp_reward;
      if (typeof active === 'boolean') patch.active = active;

      const { data, error } = await supabase
        .from('missions')
        .update(patch)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('missions').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
